from ._myTestMsg import *
