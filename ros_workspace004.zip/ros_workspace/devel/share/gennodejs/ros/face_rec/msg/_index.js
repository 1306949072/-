
"use strict";

let face_data = require('./face_data.js');
let face_results = require('./face_results.js');

module.exports = {
  face_data: face_data,
  face_results: face_results,
};
