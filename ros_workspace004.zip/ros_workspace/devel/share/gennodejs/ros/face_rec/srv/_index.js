
"use strict";

let recognition_results = require('./recognition_results.js')

module.exports = {
  recognition_results: recognition_results,
};
