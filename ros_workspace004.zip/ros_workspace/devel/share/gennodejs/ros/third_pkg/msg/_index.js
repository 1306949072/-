
"use strict";

let myTestMsg = require('./myTestMsg.js');

module.exports = {
  myTestMsg: myTestMsg,
};
