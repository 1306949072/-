
"use strict";

let myTestSrv = require('./myTestSrv.js')

module.exports = {
  myTestSrv: myTestSrv,
};
