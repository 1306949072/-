
"use strict";

let SetRelativeMove = require('./SetRelativeMove.js')

module.exports = {
  SetRelativeMove: SetRelativeMove,
};
