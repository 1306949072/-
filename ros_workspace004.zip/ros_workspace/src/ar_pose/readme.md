# 使用说明

订阅ar_track_alvar的话题，底盘对准指定的ar码

## 依赖下载安装

终端在工作空间的src目录下输入

`$ git clone https://gitee.com/reinovo/ar_track_alvar.git`

## 依赖编译方式

`$ catkin_make`



## ar_pose编译方式

`$ catkin_make`
